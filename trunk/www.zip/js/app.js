angular.module('ticket', ['ionic', 'ticket.services', 'ticket.controllers','ticket.navigation'])
/*.run(function(DB) {
	alert('1');
    DB.init();
})
*/