angular.module('ticket.config', [])
.constant('DB_CONFIG', {
    name: 'DB',
    tables: [
      {
            name: 'ticketsDb',
            columns: [
                {name: 'id', type: 'integer primary key'},
                {name: 'date', type: 'text'}
            ]
        }
    ]
});