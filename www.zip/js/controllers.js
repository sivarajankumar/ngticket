angular.module('ticket.controllers', ['ticket.services'])
.controller('ticketCtrl', function($scope, Util, $timeout) {

  $scope.oggi  = Util.today();

  function renderDate(nextDay){
          $scope.oggi.dd = nextDay.getDate();
          $scope.oggi.mm = nextDay.getMonth();
          $scope.oggi.yyyy = nextDay.getFullYear();

          $scope.oggi.nomeMese      = Util.getMonthName(nextDay.getMonth());
          $scope.oggi.nomeGiorno    = Util.getDayName(nextDay.getDay());
          $scope.oggi.numeroGiorno  = nextDay.getDate();    
  }


  $scope.incrementDate = function() {

      $timeout(function() {
          var dd1 = new Date($scope.oggi.yyyy,$scope.oggi.mm,$scope.oggi.dd);
          var tomorrow = new Date(dd1);
          tomorrow.setDate(tomorrow.getDate()+1);
          renderDate(tomorrow);            
      })



  }

  $scope.reportEvent = function(event)  {
    console.log('Reporting : ' + event.type+' direction : ' +event.gesture.direction);
    
    $timeout(function() {
      if(event.gesture.direction=='left'){
        $scope.incrementDate();
      }else{
        $scope.decrementDate();
      }
    })
  }

  $scope.decrementDate = function() {

      $timeout(function() {
          var dd1 = new Date($scope.oggi.yyyy,$scope.oggi.mm,$scope.oggi.dd);
          var tomorrow = new Date(dd1);
          tomorrow.setDate(tomorrow.getDate()-1);
          renderDate(tomorrow);     
      })


  }


  $scope.insertTicket = function() {

      
     


  }

});



/*
.controller('ticketCtrl', function($scope, Document) {
    $scope.documents = [];
    $scope.document = null;
    // Get all the documents
    /*
    Document.all().then(function(documents){
        $scope.documents = documents;
    });
    // Get one document, example with id = 2
    Document.getById(2).then(function(document) {
        $scope.document = document;
    });
});
*/