angular.module('ticket', ['ionic', 'ticket.services', 'ticket.controllers','ticket.navigation','ticket.directive'])
.run(function(DB) {
    DB.init();
    }
)
;