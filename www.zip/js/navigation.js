angular.module('ticket.navigation',[])
.config(function($stateProvider, $urlRouterProvider) {

  $stateProvider
    .state('calendario', {
      url: "/",
      templateUrl: "calendario.html",
      controller : "ticketCtrl"
    })
    .state('listaTicket', {
      url: "/listaTicket",
      templateUrl: "listaTicket.html"
    });
   $urlRouterProvider.otherwise("/"); 
});