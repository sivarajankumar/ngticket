// Ionic Starter App

// angular.module is a global place for creating, registering and retrieving Angular modules
// 'starter' is the name of this angular module example (also set in a <body> attribute in index.html)
// the 2nd parameter is an array of 'requires'
angular.module('ticket', ['ionic'])

.config(function($stateProvider, $urlRouterProvider) {

  $stateProvider
    .state('calendario', {
      url: "/",
      templateUrl: "calendario.html",
      controller : "ticketCtrl"
    })
    .state('listaTicket', {
      url: "/listaTicket",
      templateUrl: "listaTicket.html"
    });
   $urlRouterProvider.otherwise("/"); 
})

.factory('TicketFactory', function(){

  return{
     all: function() {
        var projectString = window.localStorage['projects'];
        if(projectString) {
          return angular.fromJson(projectString);
        }
        return [];
      },
      save: function(projects) {
        window.localStorage['projects'] = angular.toJson(projects);
      },
      newProject: function(projectTitle) {
        // Add a new project
        return {
          title: projectTitle,
          tasks: []
        };
      },
      getLastActiveIndex: function() {
        return parseInt(window.localStorage['lastActiveProject']) || 0;
      },
      setLastActiveIndex: function(index) {
        window.localStorage['lastActiveProject'] = index;
      }

  }
})



.factory('Util', function(){

  return{

    today: function() {
       var vtoday = new Date();

      var todayName   = this.getDayName(vtoday.getDay());
      var todayMonth  = this.getMonthName(vtoday.getMonth());
      var todayYear   = vtoday.getFullYear();
      var vdd = vtoday.getDate();
      var vmm = vtoday.getMonth();
      var vyyyy = vtoday.getFullYear();
      var todayYYYYMMDD = vtoday.getFullYear+vtoday.getMonth+vtoday.getDay;



      return { dd : vdd, mm : vmm, yyyy :vyyyy ,nomeMese: todayMonth, nomeGiorno: todayName, numeroGiorno : vdd } ;

    },


    getDayName: function (dayNo){
      var dayName = '';
      var dayNames = ['Domenica','Lunedì','Martedì','Mercoledì','Giovedì','Venerdì','Sabato','Domenica'];
      return dayNames[dayNo];
    },


   getMonthName: function (monthNo){
      var monthName = '';
      var monthNames = ['Gennaio','Febbraio','Marzo','Aprile','Maggio','Giugno','Luglio','Agosto','Settembre','Ottobre','Novembre','Dicembre'];
      return monthNames[monthNo];
   } 

  }
})

.controller('ticketCtrl', function($scope, Util, $timeout) {

  $scope.oggi  = Util.today();

  function renderDate(nextDay){
          $scope.oggi.dd = nextDay.getDate();
          $scope.oggi.mm = nextDay.getMonth();
          $scope.oggi.yyyy = nextDay.getFullYear();

          $scope.oggi.nomeMese      = Util.getMonthName(nextDay.getMonth());
          $scope.oggi.nomeGiorno    = Util.getDayName(nextDay.getDay());
          $scope.oggi.numeroGiorno  = nextDay.getDate();    
  }


  $scope.incrementDate = function() {

      $timeout(function() {
          var dd1 = new Date($scope.oggi.yyyy,$scope.oggi.mm,$scope.oggi.dd);
          var tomorrow = new Date(dd1);
          tomorrow.setDate(tomorrow.getDate()+1);
          renderDate(tomorrow);            
      })



  }

  $scope.reportEvent = function(event)  {
    console.log('Reporting : ' + event.type+' direction : ' +event.gesture.direction);
    
    $timeout(function() {
      if(event.gesture.direction=='left'){
        $scope.incrementDate();
      }else{
        $scope.decrementDate();
      }
    })
  }

  $scope.decrementDate = function() {

      $timeout(function() {
          var dd1 = new Date($scope.oggi.yyyy,$scope.oggi.mm,$scope.oggi.dd);
          var tomorrow = new Date(dd1);
          tomorrow.setDate(tomorrow.getDate()-1);
          renderDate(tomorrow);     
      })


  }


  $scope.insertTicket = function() {

      
     


  }

})

.directive('detectGestures', function($ionicGesture) {
  return {
    restrict :  'A',

    link : function(scope, elem, attrs) {
      var gestureType = attrs.gestureType;

      switch(gestureType) {
        case 'swipe':
          $ionicGesture.on('swipe', scope.reportEvent, elem);
          break;
        case 'swiperight':
          $ionicGesture.on('swiperight', scope.reportEvent, elem);
          break;
        case 'swipeleft':
          $ionicGesture.on('swipeleft', scope.reportEvent, elem);
          break;
        case 'doubletap':
          $ionicGesture.on('doubletap', scope.reportEvent, elem);
          break;
        case 'tap':
          $ionicGesture.on('tap', scope.reportEvent, elem);
          break;
      }

    }
  }
});







